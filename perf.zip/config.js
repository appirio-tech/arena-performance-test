module.exports = {
	practiceRoundId: 1527,
	practiceRoomId: 1527,
	practiceRoomType: 4,
	practiceComponentId: 4329,
	practiceDivisionId: 2,
	chatRoomId: 11,
	chatRoomType: 5,
	chatGlobalScope: 1,
	javaLanguageId: 1
}